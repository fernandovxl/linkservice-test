import { Category } from "./category";

export const CATEGORIES: Category[] = [
    {name: "Category 1", seq: 1, saved: true},
    {name: "Category 2", seq: 2, saved: true},
    {name: "Category 3", seq: 3, saved: true},
];