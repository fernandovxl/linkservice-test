export class Category {
    name: string;
    seq: number;
    saved: boolean;
}