import { Component, OnInit } from "@angular/core";
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { Category } from "../category";
import { CategoryService } from "../category.service";

@Component({
  selector: "app-categories-table",
  templateUrl: "./categories-table.component.html",
  styleUrls: ["./categories-table.component.scss"]
})
export class CategoriesTableComponent implements OnInit {
  categories: Category[];
  constructor(private categoryService: CategoryService) {}
 addDisable: boolean;
  ngOnInit() {
      this.getCategories();
      this.addDisable = false;
  }
    getCategories(): void{
        this.categories = this.categoryService.getCategories();
    }
    addCategory(): void{
        if(!this.addDisable){
            this.categoryService.addCategory();
            this.addDisable = true;
            this.getCategories();
        }
    }
    saveCategory(category: Category, index: number): void{
        if(category.name){
            category.saved = true;
            this.categoryService.saveCategory(category,index);
            this.addDisable = false;
            this.getCategories();
        }
    }
    deleteCategory(index:number): void{
        if(index >= 0 && index < this.categories.length){
            this.categoryService.deleteCategory(index);
        }
        this.categoryService.getCategories();
        
    }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.categories, event.previousIndex, event.currentIndex);
    for (let i = 0; i < this.categories.length; i++)
      this.categories[i].seq = i + 1;
  }
}
