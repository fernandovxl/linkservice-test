import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { bootstrap } from "bootstrap";
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CategoriesTableComponent } from './categories-table/categories-table.component';

@NgModule({
  declarations: [
    AppComponent,
    CategoriesTableComponent
  ],
  imports: [
    BrowserModule,
    DragDropModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
