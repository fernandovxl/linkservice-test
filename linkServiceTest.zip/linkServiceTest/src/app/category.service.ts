import { Injectable } from '@angular/core';
import { Category } from "./category";
import { CATEGORIES } from "./categories-mock";

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  constructor() { }
    
    getCategories(): Category[]{
        this.updateSeq();
        return CATEGORIES;
    }
    saveCategory(category: Category, index: number): void{
        CATEGORIES[index] = category;
    }
    addCategory(): void{
        CATEGORIES.push({
            name: "",
            seq: CATEGORIES.length +1,
            saved:false
        });
    }
    
    deleteCategory(index:number): void{
        CATEGORIES.splice(index, 1);
    }

    private updateSeq(): void{
        for(let i = 0; i<CATEGORIES.length; i++)
            CATEGORIES[i].seq = i + 1;
    }
}
